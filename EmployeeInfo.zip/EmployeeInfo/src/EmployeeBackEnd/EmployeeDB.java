/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeeBackEnd;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author ram-pt3531
 */
public class EmployeeDB {
    static public int idCreator=6;
    private int id;
    private int age;
    private String name;
    private String department;
    private String desigination;
    private String reportingTo;
   public static void delete(List<EmployeeDB>emp,List<EmployeeDB> key)
   {
           for(int i=0;i<key.size();i++)
          {
              for(int j=0;j<emp.size();j++)
              {
                  if(emp.get(j).getId()==key.get(i).getId())
                  {
                      emp.remove(j);
                      break;
                  }
              }
          }
   }
   public static void Update(List<EmployeeDB> emp,List<EmployeeDB> keyTable,List<Integer> choiceForField,List<String> key)
   {
     for(int i=0;i<keyTable.size();i++)
          {
              for(int j=0;j<emp.size();j++)
              {
                  
                  EmployeeDB temp=emp.get(j);
                  if(temp.getId()==keyTable.get(i).getId())
                  {
                     for(int k=0;k<choiceForField.size();k++)
                     {
                        String keyTemp=key.get(k);
                         switch(choiceForField.get(k))
                         {
                           
                             case 1: temp.setAge(Integer.parseInt(keyTemp));
                                     break;
                             case 2: temp.setName(keyTemp);
                                     break;
                             case 3: temp.setDepartment(keyTemp);
                                     break;
                             case 4: temp.setDesigination(keyTemp);
                                     break;
                             case 5: temp.setReportingTo(keyTemp);
                         }
                     }
                     
                  }
              }
          }
     }
   public EmployeeDB(int id, int age, String name, String department, String desigination, String reportingTo) {
        this.id = id;
        this.age = age;
        this.name = name;
        this.department = department;
        this.desigination = desigination;
        this.reportingTo = reportingTo;
    }
    //Find the employess that comes under reporting staff

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDesigination() {
        return desigination;
    }

    public void setDesigination(String desigination) {
        this.desigination = desigination;
    }

    public String getReportingTo() {
        return reportingTo;
    }

    public void setReportingTo(String reportingTo) {
        this.reportingTo = reportingTo;
    }

    public static List<EmployeeDB> reportingStaff(List<EmployeeDB> emp,String key)
    {
        List<EmployeeDB> temp=new ArrayList<EmployeeDB>();
        for(int i=0;i<emp.size();i++)
        {
           
            if(stringMatch(1, emp.get(i).reportingTo,key))
            {
               
                temp.add(emp.get(i));
            }
        }
       return temp;
    }
    public static void insert(List<EmployeeDB> emp,int id,int age,String name,String Department,String Desigination,String reportingTo)
    {
        emp.add(new EmployeeDB(id, age, name, Department, Desigination, reportingTo));
    }
    
    public static List<EmployeeDB> search(List<EmployeeDB> e,String key,int fieldChoice,int chForOperatio)
    {
     
        List<EmployeeDB> temp=new ArrayList<EmployeeDB>();
        switch(fieldChoice)
        {
            case 1: 
                   
                    //Check for Each Record in the table one by one that matches the enterd number
                    for(int i=0;i<e.size();i++)
                    {
                      if(numberMatch(chForOperatio, e.get(i).age, Integer.parseInt(key)))
                      {
                      temp.add(e.get(i));
                      }
                    }
                 
                    break;
            case 2: 
                    //Check for Each Record in the table one by one that matches the enterd string
                    for(int i=0;i<e.size();i++)
                    {
                        if(stringMatch(chForOperatio,e.get(i).name, key))
                        {
                            temp.add(e.get(i));
                        }
                    }
                   
                    break;
              case 3: 
                    for(int i=0;i<e.size();i++)
                    {
                        if(stringMatch(chForOperatio,e.get(i).department, key))
                        {
                            temp.add(e.get(i));
                        }
                    }
                 
                    break;
                  
                 case 4: 
                   for(int i=0;i<e.size();i++)
                    {
                        if(stringMatch(chForOperatio,e.get(i).desigination, key))
                        {
                            temp.add(e.get(i));
                        }
                    }
                     break;
                  
                  case 5: 
                    
                    for(int i=0;i<e.size();i++)
                    {
                        if(stringMatch(chForOperatio,e.get(i).reportingTo, key))
                        {
                            temp.add(e.get(i));
                        }
                    }
                      break;
                  case 6:
                      for(int i=0;i<e.size();i++)
                      {
                          if(numberMatch(chForOperatio, e.get(i).id, Integer.parseInt(key)))
                                  
                                  {
                                      temp.add(e.get(i));
                                  }
                      }
              }
             
           
       return temp;
        }
     public static List<String> reportTree(List<EmployeeDB> e,String key,List<String> sl)
    {
        
        stringHolder s=new stringHolder();
        for(int i=0;i<e.size();i++)
        {
            if(e.get(i).name.equals(key)&&e.get(i).reportingTo!=null)
            {
                sl.add(e.get(i).reportingTo);
                return reportTree(e, e.get(i).reportingTo,sl);
            }
        }
       return sl;
                
    }
     public static SummaryDetail Summary(List<EmployeeDB> passeEemployee,int choiceOfField)
     {
         EmployeeDB employeeObject;
        
         int employeeSize=passeEemployee.size();
        boolean visited[]=new boolean[employeeSize];
        Arrays.fill(visited, false);
        SummaryDetail summaryDetail;
        List<List<EmployeeDB>> employeesToBeClassified=new ArrayList<List<EmployeeDB>>();
        List<String> departmentOrDesigination=new ArrayList<String>();
        List<Integer> countList=new ArrayList<Integer>();
        switch(choiceOfField)
        {
            case 1: for(int i=0;i<employeeSize;i++)
             {
                         
            if(visited[i]==true)
              continue;
             EmployeeDB visitedEmployee;
            employeeObject=passeEemployee.get(i);
            int count=1;
            List<EmployeeDB> employeesListPerDepartment=new ArrayList<EmployeeDB>();
            
            employeesListPerDepartment.add(employeeObject);
            for(int j=i+1;j<employeeSize;j++)
              {
                visitedEmployee=passeEemployee.get(j);
                if(visitedEmployee.department.equals(employeeObject.department))
                {
                    visited[j]=true;
                    employeesListPerDepartment.add(visitedEmployee);
                    count++;
                }
               }
            
            employeesToBeClassified.add(employeesListPerDepartment);
            departmentOrDesigination.add(employeeObject.getDepartment());
            }
            case 2: for(int i=0;i<employeeSize;i++)
             {
                         
            if(visited[i]==true)
              continue;
             EmployeeDB visitedEmployee;
            employeeObject=passeEemployee.get(i);
            int count=1;
            List<EmployeeDB> employeesListPerDepartment=new ArrayList<EmployeeDB>();
            
            employeesListPerDepartment.add(employeeObject);
            for(int j=i+1;j<employeeSize;j++)
              {
                visitedEmployee=passeEemployee.get(j);
                if(visitedEmployee.desigination.equals(employeeObject.getDesigination()))
                {
                    visited[j]=true;
                    employeesListPerDepartment.add(visitedEmployee);
                    count++;
                }
               }
            
            employeesToBeClassified.add(employeesListPerDepartment);
            departmentOrDesigination.add(employeeObject.getDesigination());
            }

         } 
        return summaryDetail=new SummaryDetail(employeesToBeClassified,departmentOrDesigination);
     }
    //It takes three perameter one is for choice for comparision, another one is the number on which the comparision is made another one is the kay on which the number is compared Check the give constrain and give boolean value.
    private static boolean numberMatch(int choice,int num,int key)
    {
        switch(choice)
        {
            case 1:return num== key;
            case 2:return num!=key;
            case 3:return num>key;
            case 4:return num<key;
            default: return false;
        }
    }
    //It takes 3 perameter one is choice for the comparesion, another one is the String on which the comparision is made, Another one  is the key with which the string is compared
    private static boolean stringMatch(int choice,String wordToBeMatched,String key)
    {
        switch(choice)
        {
            case 1:return key.equals(wordToBeMatched);
            case 2:return !key.equals(wordToBeMatched);
            case 3:return wordToBeMatched.indexOf(key)==0;
            case 4:return (wordToBeMatched.indexOf(key)+key.length())==(wordToBeMatched.length());
            case 5:return wordToBeMatched.contains(key);
            case 6:return !wordToBeMatched.contains(key);
            default: return false;
        }
    }
}




