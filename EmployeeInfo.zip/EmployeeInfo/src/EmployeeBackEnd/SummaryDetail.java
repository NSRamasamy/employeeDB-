/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeeBackEnd;

import java.util.List;

/**
 *
 * @author ram-pt3531
 */
public class SummaryDetail {
    private List<List<EmployeeDB>>employees;
    private List<String> departmentOrDesigination;
    


    public List<List<EmployeeDB>> getEmployees() {
        return employees;
    }

    public void setEmployees(List<List<EmployeeDB>> employees) {
        this.employees = employees;
    }
    



    public List<String> getDepartmentOrDesigination() {
        return departmentOrDesigination;
    }

    public void setDepartmentOrDesigination(List<String> DepartmentOrDesigination) {
        this.departmentOrDesigination = departmentOrDesigination;
    }

    public SummaryDetail(List<List<EmployeeDB>> employees, List<String> departmentOrDesigination) {
        
        this.employees = employees;
        this.departmentOrDesigination = departmentOrDesigination;
    }

    
    public int length()
    {
       return employees.size();
    }

   
}
