import java.util.List;
import java.util.Scanner;

class EmployeeDB {
    private int id;
    private int age;
    private String name;
    private String department;
    private String desigination;
    private String reportingTo;
    private static Scanner sc=new Scanner(System.in);
    public EmployeeDB(int id, int age, String name, String department, String desigination, String reportingTo) {
        this.id = id;
        this.age = age;
        this.name = name;
        this.department = department;
        this.desigination = desigination;
        this.reportingTo = reportingTo;
    }
    //Find the employess that comes under reporting staff
    public static void reportingStaff(EmployeeDB[] emp,int length)
    {
        System.out.println("Enter the reporting to staff");
        String key=sc.next();
          
        for(int i=0;i<=length;i++)
        {
            if(stringMatch(1, emp[i].reportingTo,key))
            {
                System.out.println(emp[i].name);
            }
        }
    }
    //Display Table Function
     public static void show(EmployeeDB[] e,int tableLength)
        {
            if(tableLength==-1)
            {
                System.out.println("No Record");
                return;
            }
            //Display of column title
                System.out.format("%-15s%-15s%-15s%-15s%-15s%-15s\n","id","age","name","department","desigination","reporting to");
            //Display of data inside the table
            for(int i=0;i<=tableLength;i++)
            {
                System.out.format("%-15s%-15s%-15s%-15s%-15s%-15s\n",e[i].id,e[i].age,e[i].name,e[i].department,e[i].desigination,e[i].reportingTo);
            }
        }
     //Search in Table 
    public static EmployeeObjectHolder search(EmployeeDB[] e,int length)
    {
        EmployeeObjectHolder eob=new EmployeeObjectHolder();
        EmployeeDB[] temp=new EmployeeDB[length+1];
        int tableLength=-1;
        int choice;
        //Fields on which the search is made
        System.out.println("\n1.Age\n2.Name\n3.Department\n4.Desigination\n5.Reportin To");
        choice=sc.nextInt();
        int key;
       
        switch(choice)
        {
            case 1: int choiceOne=numberChoice();//197
                    System.out.println("Enter the number");
                    key=sc.nextInt();
                    //Check for Each Record in the table one by one that matches the enterd number
                    for(int i=0;i<=length;i++)
                    {
                      if(numberMatch(choiceOne, e[i].age, key))
                      {
                      tableLength++;
                      temp[tableLength]=e[i];
                      }
                    }
                    show(temp, tableLength);//Display the resultant table
                    eob.emp=temp;
                    eob.tableLength=tableLength;
                    break;
            case 2: int choice2=stringChoice();//String Operations
                    System.out.println("Enter the word");
                    String key2=sc.next();
                    //Check for Each Record in the table one by one that matches the enterd string
                    for(int i=0;i<=length;i++)
                    {
                        if(stringMatch(choice2,e[i].name, key2))
                        {
                            tableLength++;
                            temp[tableLength]=e[i];
                        }
                    }
                    show(temp, tableLength);
                    eob.emp=temp;
                    eob.tableLength=tableLength;
                    break;
              case 3: int choice3=stringChoice();
                    System.out.println("Enter the Department");
                    String key3=sc.next();
                    for(int i=0;i<=length;i++)
                    {
                        if(stringMatch(choice3,e[i].department, key3))
                        {
                            tableLength++;
                            temp[tableLength]=e[i];
                        }
                    }
                    System.out.println(tableLength);
                    show(temp, tableLength);
                    eob.emp=temp;
                    eob.tableLength=tableLength;
                    break;
                  
                 case 4: int choice4=stringChoice();
                    System.out.println("Enter the desigination");
                    String key4=sc.next();
                   for(int i=0;i<=length;i++)
                    {
                        if(stringMatch(choice4,e[i].desigination, key4))
                        {
                            tableLength++;
                            temp[tableLength]=e[i];
                        }
                    }
                     show(temp, tableLength);
                     eob.emp=temp;
                    eob.tableLength=tableLength;
                     break;
                  
                  case 5: int choice5=stringChoice();
                    System.out.println("Enter the Reporting Staff");
                    String key5=sc.next();
                    
                    for(int i=0;i<=length;i++)
                    {
                        if(stringMatch(choice5,e[i].reportingTo, key5))
                        {
                            tableLength++;
                            temp[tableLength]=e[i];
                        }
                    }
                      show(temp, tableLength);
                      eob.emp=temp;
                      eob.tableLength=tableLength;
                      break;
         }
       
       
            System.out.println("Do you want to search furthur\n1.yes\n2.No");
            //Furthur filter if yes
            if(sc.nextInt()==1)
               return eob=search(temp,tableLength);//Return the filtered value that was returned by post 
            else 
                return eob;//retuen the filtered value
        }
    //Display the number comparision
    private static int numberChoice()
    {
        
        System.out.println("\n1.equals\n2.Not Equals\n3.Greater Than\n4. Smaller Than");
        return sc.nextInt();
    }
    public static void reportTree(EmployeeDB[] e,int tableLength,String key)
    {
        for(int i=0;i<=tableLength;i++)
        {
            if(e[i].name.equals(key)&&e[i].reportingTo!=null)
            {
                System.out.print("->"+e[i].reportingTo);
                reportTree(e, tableLength, e[i].reportingTo);
            }
        }
    }
    public void delete(List<EmployeeDB> e)
    {
        
    }
    //It takes three perameter one is for choice for comparision, another one is the number on which the comparision is made another one is the kay on which the number is compared Check the give constrain and give boolean value.
    private static boolean numberMatch(int choice,int num,int key)
    {
        switch(choice)
        {
            case 1:return num== key;
            case 2:return num>key;
            case 3:return num<key;
            default: return false;
        }
    }
    //It displays the string comparision.
    private static int stringChoice()
    {
        
        System.out.println("\n1.equals\n2.Not Equals\n3.start with\n4.end with\n5.contains\n5.not contains");
        return sc.nextInt();
    }
    //It takes 3 perameter one is choice for the comparesion, another one is the String on which the comparision is made, Another one  is the key with which the string is compared
    private static boolean stringMatch(int choice,String wordToBeMatched,String key)
    {
        switch(choice)
        {
            case 1:return key.equals(wordToBeMatched);
            case 2:return !key.equals(wordToBeMatched);
            case 3:return wordToBeMatched.indexOf(key)==0;
            case 4:return (wordToBeMatched.indexOf(key)+key.length())==(wordToBeMatched.length());
            case 5:return wordToBeMatched.contains(key);
            case 6:return !wordToBeMatched.contains(key);
            default: return false;
        }
    }
  
}
//Holds the EmployeeDB object and length
class EmployeeObjectHolder{
    protected EmployeeDB[] emp;
    protected int tableLength;
}


