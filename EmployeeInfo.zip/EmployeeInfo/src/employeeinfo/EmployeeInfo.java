/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeinfo;
import InputOperation.InputOperation;
import EmployeeBackEnd.*;
import com.sun.corba.se.pept.encoding.InputObject;
import java.util.ArrayList;
import java.util.List;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author ram-pt3531
 */
public class EmployeeInfo {
    
  static InputOperation inputOperation=new InputOperation();
   static Scanner sc=new Scanner(System.in);
    public static void main(String[] args) {
        // Database Entry
        List<EmployeeDB> emp=new ArrayList<EmployeeDB>();
        emp.add(new EmployeeDB(1, 25, "Raghul", "CEO", "CEO", ""));
        emp.add(new EmployeeDB(2, 36, "Ramasamy","MDM","Developer", "Raghul"));
        emp.add(new EmployeeDB(3, 28, "Kandha kumar", "managing", "HR Manager", "Raghul"));
        emp.add(new EmployeeDB(4, 32, "Srikanth", "MDM", "TL" ,"Ramasamy"));
        emp.add(new EmployeeDB(5, 26, "Vignesh", "HR", "associative hr", "Kandha kumar"));
        emp.add(new EmployeeDB(6,48, "Naveen", "MDM", "Developer", "Ramasamy"));
        show(emp);
        DBOperation(emp);
        int choice;
        
        //Showing option
        EmployeeObjectHolder eoh=new EmployeeObjectHolder();
      
    
        
        
        
    }
    public static void DBOperation(List<EmployeeDB> emp)
    {
            int choice;
            System.out.println("\n1.Show\n2.Search\n3.Report Staffs\n4.Report Tree\n5.Insert\n6.Remove\n7.Update\n8.Summary\n9End");
            choice=InputOperation.getNumberWithLimit(9);
            switch(choice)
            {
                case 1: show(emp);//Display table
                        break;
                case 2:List<EmployeeDB> temp;
                       temp=Filter.filter(emp);
                       //show(temp);
                       break;
                case 3: List<EmployeeDB> temp1;
                         //Find the employess that comes under reporting staff
                        System.out.println("Enter the reportingTo Staff");
                        String key=InputOperation.getString();
                        temp1=EmployeeDB.reportingStaff(emp,key);
                        for(int i=0;i<temp1.size();i++)
                        {
                            
                            System.out.println(temp1.get(i).getName());
                        }
                        break;
                case 4: System.out.println("Enter the employee name");// Generate Report Tree
                        String empName = InputOperation.getString();
                        System.out.print(empName);
                        List<String> sl=new ArrayList<String>();
                        sl=EmployeeDB.reportTree(emp,empName,sl);
                        for(int i=0;i<sl.size();i++)
                        {
                            System.out.print("->"+sl.get(i));
                        }
                        break;
                case 5: 
                        System.out.println("Enter the age");
                        int age=InputOperation.getNumber();
                        System.out.println("Enter the name");
                        String Name=InputOperation.getString();
                        System.out.println("Enter the department");
                        String Department=InputOperation.getString();
                        System.out.println("Enter the desigination");
                        String Desigination=InputOperation.getString();
                        System.out.println("Enter the Reporting Staff");
                        String ReportinTo=getReportingStaff(emp, InputOperation.getString());
                        EmployeeDB.insert(emp, ++EmployeeDB.idCreator, age, Name, Department, Desigination, ReportinTo);
                        show(emp);
                        break;
                case 6: delete(emp);
                        show(emp);
                        break;
                case 7: upDate(emp);       
                         break;
                case 8: summary(emp);//Exit program
                        break;
                case 9: return;
                default:System.out.println("Enter the valid choice");
                        
            }
          
            System.out.println("Do you want to continue the furthur DB operation?\n1.Yes \n2.No");
            int ch2=InputOperation.getNumberWithLimit(2);
            if(ch2==1)
            {
                DBOperation(emp);
            }
            else
            {
                return;
            }
    }
    private static void delete(List<EmployeeDB> e)
    {
          List<EmployeeDB> temp;
          temp=Filter.filter(e);
          System.out.println("Are you sure, do you want to delete the filtered table?\n1.Yes\n2.No");
           List<EmployeeDB> employeesComesUnderFilteredTable=new ArrayList<EmployeeDB>();
          if(InputOperation.getNumberWithLimit(2)==1)
          {
          for(int i=0;i<temp.size();i++)
          {
              employeesComesUnderFilteredTable=EmployeeDB.reportingStaff(e,temp.get(i).getName());
          }
          if(employeesComesUnderFilteredTable.size()>0)
          {
              show(employeesComesUnderFilteredTable);
              System.out.println("These employess comes under the respective reporting staff Do you want to change the reportin staff or stop deletion\n1.Yes\n2.No");
              int ch=InputOperation.getNumberWithLimit(2);
              if(ch==1)
              {
                  for(int i=0;i<employeesComesUnderFilteredTable.size();i++)
                  {
                   EmployeeDB temp1=employeesComesUnderFilteredTable.get(i);
                  System.out.println("Enter the reporting staff name to update for "+temp1.getName());
                  temp1.setReportingTo(getReportingStaff(e,InputOperation.getString()));
                  
                  }
              }
              else 
                  return;
          }
          EmployeeDB.delete(e,temp);
          if(temp.size()==0)
          {
              System.out.println("No Row is affected");
              return ;
          }
          displayNumberOfAffetcedRow(temp.size());
          }
    }
    private static String getReportingStaff(List<EmployeeDB> emp,String reportingStaff)
    {
        String tempReportingStaff=reportingStaff;
        int found=0;
       for(int i=0;i<emp.size();i++)
       {
           if(emp.get(i).getReportingTo().equals(reportingStaff))
           {
               found=1;
               break;
           }
       }
       if(found==0)
       {
           System.out.println("Reporting staff is not found Enter another reportingstaff");
           return tempReportingStaff=getReportingStaff(emp,InputOperation.getString());
       }
       
       return tempReportingStaff;
    }
    public static void displayNumberOfAffetcedRow(int size)
    {
        if(size==1)
      {
          System.out.println(size+" row is affected");
      }
      else if(size>1)
            System.out.println(size+" rows are affected");
    }
    private static void upDate(List<EmployeeDB>emp)
    {
        List<EmployeeDB> temp;
        System.out.println("Choose the field on which basis the filter to be applied");
        temp=Filter.filter(emp);
        System.out.println("Do you want to contineu\n1.Yes\n2.No");
        if(InputOperation.getNumberWithLimit(2)==1)
        {
        System.out.println("Choose the field that you want to update and Enter the key to update");
        System.out.println("\n1.Age\n2.Name\n3.Department\n4.Desigination\n5.Reportin To\n6.Finished");
        List<Integer> choiceForField=new ArrayList<Integer>();
        List<String> key=new ArrayList<String>();
        while(true)
        {
            
            int intTemp;
            String stringTemp;
            intTemp=InputOperation.getNumberWithLimit(6);
            if(intTemp==6  || choiceForField.size()==6)
            {
                break;
            }
            if(choiceForField.contains(intTemp))
            {
                System.out.println("You have already choosen this option Do you want to change it?\n1.Yes\n2.No");
                if(InputOperation.getNumberWithLimit(2)==1)
                {
                    System.out.println("Enter the input");
                    int tempCh=choiceForField.indexOf(intTemp);
                    choiceForField.set(tempCh,InputOperation.getNumber());
                    if(intTemp==5)
                    key.set(tempCh,getReportingStaff(emp, InputOperation.getString()));
                    else
                    key.set(tempCh,InputOperation.getString());
                }
                continue;
            }
            choiceForField.add(intTemp);
            stringTemp=InputOperation.getString();
            if(intTemp==5)
                key.add(getReportingStaff(emp, stringTemp));
            else
            key.add(stringTemp);
        }
        if(choiceForField.size()>0)
        {
       System.out.println("Are you sure, Do you want to update\n1.Yes\n2.No");
       if(InputOperation.getNumberWithLimit(2)==1)
       {
      EmployeeDB.Update(emp, temp, choiceForField, key);
      show(emp);
      int size=temp.size();
      displayNumberOfAffetcedRow(size);
        }
        }
       }
        else
           System.out.println("No Row is affected");
    }
  
      
         public static void show(List<EmployeeDB> e)
        {
            if(e.size()==0)
            {
                System.out.println("No Record");
                return;
            }
            //Display of column title
                System.out.format("%-15s%-15s%-15s%-15s%-15s%-15s\n","id","age","name","department","desigination","reporting to");
            //Display of data inside the table
            for(int i=0;i<e.size();i++)
            {
                System.out.format("%-15s%-15s%-15s%-15s%-15s%-15s\n",e.get(i).getId(),e.get(i).getAge(),e.get(i).getName(),e.get(i).getDepartment(),e.get(i).getDesigination(),e.get(i).getReportingTo());
            }
        }
      public static void summary(List<EmployeeDB> employee)
      {
          System.out.println("Enter the base field of summary\n1.Department\n2.Desigination");
          SummaryDetail summaryDetail=EmployeeDB.Summary(employee,inputOperation.getNumber());
          for(int i=0;i<summaryDetail.length();i++)
          {
              String departmentOrDesigintion=summaryDetail.getDepartmentOrDesigination().get(i);
              System.out.println("Employee that comes under  "+departmentOrDesigintion+": ");
              List<EmployeeDB> employeesUndereDepartment=summaryDetail.getEmployees().get(i);
              
              for(int j=0;j<employeesUndereDepartment.size();j++)
              {
                  System.out.println(employeesUndereDepartment.get(j).getName());
              }
              System.out.println("Number of employees that comes under "+departmentOrDesigintion+" : "+employeesUndereDepartment.size());
              
          }
      }
}
