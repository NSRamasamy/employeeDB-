/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeinfo;

import EmployeeBackEnd.EmployeeDB;
import InputOperation.InputOperation;
import static employeeinfo.EmployeeInfo.show;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ram-pt3531
 */
public class Filter {
 protected static List <EmployeeDB> filter(List<EmployeeDB> emp)
     {
                  String key;
                  List<EmployeeDB> temp=new ArrayList<EmployeeDB>();
              System.out.println("\n1.Age\n2.Name\n3.Department\n4.Desigination\n5.Reportin To\n6.id");
                        int choiceForField;
                        choiceForField=InputOperation.getNumberWithLimit(6);
                        int ch;
                        if(choiceForField==1||choiceForField==6)
                        {
                        ch=numberChoice();
                        System.out.println("Enter the number");
                        }
                        else
                        {
                        ch=stringChoice();
                        System.out.println("Enter the string");
                        }
                        key=InputOperation.getString();
                        temp=EmployeeDB.search(emp,key,choiceForField,ch);
                        show(temp);
                        if(temp.size()==1)
                        System.out.println(temp.size()+" row is filtered");
                        else
                          System.out.println(temp.size()+" rows are filtered");
                        if(temp.size()<2)
                            return temp;
                         System.out.println("Do you want to filter furthur \n1.Yes\n2.No");
                        if(InputOperation.getNumberWithLimit(2)==1)
                           return temp=filter(temp);
                        else
                            return temp;
                        
            }
   private static int numberChoice()
        {
        
        System.out.println("\n1.equals\n2.Not Equals\n3.Greater Than\n4. Smaller Than");
        return InputOperation.getNumberWithLimit(4);
       }
        private static int stringChoice()
       {
        
        System.out.println("\n1.equals\n2.Not Equals\n3.start with\n4.end with\n5.contains\n6.not contains");
        return InputOperation.getNumberWithLimit(6);
       }
}
