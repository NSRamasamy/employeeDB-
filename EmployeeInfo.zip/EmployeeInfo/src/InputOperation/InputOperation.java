/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InputOperation;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author ram-pt3531
 */
public class InputOperation {
    static Scanner sc=new Scanner(System.in);
        public static int getNumber()
    {
        String s;
        s=sc.nextLine();
        if(isNumber(s))
        {
            return Integer.parseInt(s);
        }
        else
        {
         System.out.println("Enter the valid number");
          s=String.valueOf(getNumber());
        }
        return Integer.parseInt(s);
    }
        public static int getNumberWithLimit(int lim)
        {
            int val=getNumber();
            if(val>lim)
            {
                System.out.println("Enter the correct limit");
                return val=getNumberWithLimit(lim);
            }
            return val;
        }
    public static boolean isNumber(String s)
    {
        try{
            Integer.parseInt(s);
            return true;
           }
      catch(NumberFormatException e)
      {
          return false;
      }
    }
    public static String getString()
    {
        String s;
        s=sc.nextLine();
        if(isSpecialChar(s))
        {
            System.out.println("Enter the valid words");
            s=getString();
        }
        else
            return s; 
       return s;
    }
     public static boolean isSpecialChar(String s)
    {
        Pattern p=Pattern.compile("[^A-Za-z0-9 ]");
        Matcher m = p.matcher(s);
        return m.find();
    }
    
}
